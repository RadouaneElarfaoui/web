<?php


?>
<!DOCTYPE html>
<html>
<head>
<title>x - o</title>
<style type="text/css">
.game {
width:255px;
margin:auto;
padding:auto;
font-family:Courier new,monospace;
color:white;

}
.title {
background-color:rgb(51, 142, 233);
position:relative;
text-align:center;
font-size:xx-large;
margin:0 10px;

}
.square {
background-color:purple;
margin:2px;
width:80px;
height:80px;
float:right;
text-align:center;
font-size:60px;
}
.square:hover{
background:gray;
}
samp {
color:green;
}



</style>
</head>
<body>
	
<div class="game" >
	<div class="title" id="title" > <samp>X O</samp>game </div>


		<div class="square"  id="b1" onclick="game(this.id)" ></div>
		<div class="square"  id="b2" onclick="game(this.id)"></div>
		<div class="square"  id="b3" onclick="game(this.id)"></div>

		<div class="square"  id="b4" onclick="game(this.id)"></div>
		<div class="square"  id="b5" onclick="game(this.id)"></div>
		<div class="square"  id="b6" onclick="game(this.id)"></div>

		<div class="square"  id="b7" onclick="game(this.id)"></div>
		<div class="square"  id="b8" onclick="game(this.id)"></div>
		<div class="square"  id="b9" onclick="game(this.id)"></div>


</div>
<script type="text/javascript">
let title=document.querySelector('.title');
let turn ='X';
play =0;
function game(id)
{ 
if(play==0)
{
	element=document.getElementById(id);
	if(turn=='X'&& element.innerHTML==''){
	element.innerHTML='X';
	title.innerHTML='O turn';
	turn='O';
	}
	else if(turn=='O'&&element.innerHTML==''){
	element.innerHTML='O';
	title.innerHTML='X  turn';
	
	turn='X';
	}
	winner();
	}
	
}
function winner()
{
let b=[];
for( let i=1;i<10;i++){
b[i]=document.getElementById('b'+i).innerHTML;
}
if(b[1]==b[2]&&b[2]==b[3]&&b[3]=='X'||b[4]==b[5]&&b[5]==b[6]&&b[6]=='X'||b[7]==b[8]&&b[8]==b[9]&&b[9]=='X'||b[1]==b[5]&&b[5]==b[7]&&b[7]=='X'||b[2]==b[5]&&b[5]==b[8]&&b[8]=='X'||b[3]==b[6]&&b[6]==b[9]&&b[9]=='X'||b[1]==b[5]&&b[5]==b[9]&&b[9]=='X'||b[3]==b[5]&&b[5]==b[7]&&b[7]=='X'){
title.innerHTML='X winner ';
play=1;
setInterval(function(){title.innerHTML+= '.'},1000);
setTimeout(function(){location.reload()},4000);
 	}
if(b[1]==b[2]&&b[2]==b[3]&&b[3]=='O'||b[4]==b[5]&&b[5]==b[6]&&b[6]=='O'||b[7]==b[8]&&b[8]==b[9]&&b[9]=='O'||b[1]==b[5]&&b[5]==b[7]&&b[7]=='O'||b[2]==b[5]&&b[5]==b[8]&&b[8]=='O'||b[3]==b[6]&&b[6]==b[9]&&b[9]=='O'||b[1]==b[5]&&b[5]==b[9]&&b[9]=='O'||b[3]==b[5]&&b[5]==b[7]&&b[7]=='O'){
title.innerHTML='O winner ';
play=1;
setInterval(function(){title.innerHTML+= '.'},1000);
setTimeout(function(){location.reload()},4000);
}
}
</script>
</body>
</html>