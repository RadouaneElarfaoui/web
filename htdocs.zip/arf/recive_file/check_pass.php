<?php
$password = $_POST["password"];
if ($password == "file") {
echo "succes login";
header('Location: /arf/upload_file/upload/', TRUE, 302);
    }
    else {
echo "password incorrect";
    }
?>